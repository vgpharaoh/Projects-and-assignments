public class Term {
	/*Define the appropriate fields and constructors for Term class.
	 * Hint: You can take the Term instance in the FileOperator class as reference.
	 */


}
