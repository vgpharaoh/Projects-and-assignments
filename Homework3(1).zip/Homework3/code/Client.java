public class Client {

	public static void main(String[] args)  {
		
		SearchHelper sh = new SearchHelper();

		System.out.println("TEST CASE 1");
		System.out.println("-----------------------------------------------");
		sh.searchInFile("/Users/denizsonmez/Downloads/inputfiles/inputs/cities1.txt", "Sha", 3);
		System.out.println("-----------------------------------------------");
		
		System.out.println("TEST CASE 2");
		System.out.println("-----------------------------------------------");
		sh.searchInFile("/Users/denizsonmez/Downloads/inputfiles/inputs/baby-names1.txt", "Jo", 7);
		System.out.println("-----------------------------------------------");
		
		System.out.println("TEST CASE 3");
		System.out.println("-----------------------------------------------");
		sh.searchInFile("/Users/denizsonmez/Downloads/inputfiles/inputs/imdb-votes1.txt", "The", 10);
		System.out.println("-----------------------------------------------");
		
		System.out.println("TEST CASE 4");
		System.out.println("-----------------------------------------------");
		sh.searchInFile("/Users/denizsonmez/Downloads/inputfiles/inputs/artists1.txt", "A", 10);
		System.out.println("-----------------------------------------------");
		
		System.out.println("TEST CASE 5");
		System.out.println("-----------------------------------------------");
		sh.searchInFile("/Users/denizsonmez/Downloads/inputfiles/inputs/pokemon.txt", "Sta", 5);
		System.out.println("-----------------------------------------------");
		
		System.out.println("TEST CASE 6");
		System.out.println("-----------------------------------------------");
		sh.searchInFile("/Users/denizsonmez/Downloads/inputfiles/inputs/pu-buildings.txt", "C", 6);
		System.out.println("-----------------------------------------------");
		
		System.out.println("TEST CASE 7");
		System.out.println("-----------------------------------------------");
		sh.searchInFile("/Users/denizsonmez/Downloads/inputfiles/inputs/trademarks1.txt", "DA", 7);
		System.out.println("-----------------------------------------------");
		
	}

}
