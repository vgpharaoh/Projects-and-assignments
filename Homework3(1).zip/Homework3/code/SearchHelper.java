public class SearchHelper {
	
	public int binarySearch(Term[] terms, int l, int r, String prefix) 
	{ 
		/*Search the first occurrence of a word starts with the given prefix in the list of terms*/
		
		/*You might not find the first occurrence of a word starts with the given prefix with the traditional 
		binary search approach. Study how you need to modify binary search algorithm so that you can 
		find the first occurrence of an element in an array with duplicates.*/
		
		/*Return the first index of the occurrence of a term starts with the given prefix
		  found in the array, return -1 if not found*/
		
	  
	   return -1; 
	}
	
	public void searchInFile(String filePath, String prefix, int N) {
		/*Store the terms given in the file you read from the filePath in an array of terms. 
		 * Hint: Use readTerms method of FileOperator class*/
		
		/*Sort the array by the alphabetical order of the terms
		 * Hint: Use sort method of Quicksort class with the appropriate comparator*/
		
		/*Find the FIRST occurrence of a word starting with the given prefix by calling binary search
		 * If you did not implement binary search in a way that you can find the first index of a matching term,
		 * you need to do an additional linear search here to find the first index*/
		
		/*Starting from the first index you found, store all the words starting 
		 with the given prefix in another array*/

		
		/*Sort the array that has the matched terms by the weights of the terms (descending order)*/

		
		/*Print out the first 'N' elements in the matched array*/ 

	}

}
