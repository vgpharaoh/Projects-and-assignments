import java.util.Comparator;

public class SortByWeight implements Comparator<Term> {
	@Override
	/*Override the compare method so that you can sort Terms by weight in DESCENDING order*/
	public int compare(Term o1, Term o2) {
		return -1;
	}

}
