import java.util.Comparator;

public class SortByText implements Comparator<Term> {
	/*
	 * Override the compare method so you can sort the terms in the alphabetical
	 * order
	 */
	@Override
	public int compare(Term o1, Term o2) {
		return -1;
	}

}