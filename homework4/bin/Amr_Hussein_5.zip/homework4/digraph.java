package homework4;

import java.util.LinkedList;

public class digraph {
	//To Do
	public final int V;
	private LinkedList<Integer>[] adj;
	public digraph(int n) {
		//To Do
		this.V = n;
		adj = (LinkedList<Integer>[]) new LinkedList[V];
		for(int v=0; v<V; v++)
			adj[v] = new LinkedList<Integer>();
	}
	public void addEdge(int source, int target) {
		//To Do
		adj[source].add(target);
	}
	
	public Iterable<Integer> adj(int v){
		//To Do
		return adj[v];
	}
	
}
